c = 299792458
k_b = 1.38064852 * 10**-23  # Boltzmann constant in J/K
