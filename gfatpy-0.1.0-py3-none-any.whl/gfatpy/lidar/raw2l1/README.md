# lidar_raw2l1

management scripts for the creation of netcdf files from lidar binary raw files
